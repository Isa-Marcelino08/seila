
const About = () => {
  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center gap-10">
          <div className="w-full md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1649972904349-6e44c42644a7" 
              alt="Profile" 
              className="rounded-lg shadow-lg w-full max-w-md mx-auto"
            />
          </div>
          <div className="w-full md:w-1/2">
            <h2 className="text-3xl font-bold mb-4">Sobre Mim</h2>
            <p className="text-gray-600 mb-6">
              Olá! Sou um desenvolvedor apaixonado por criar soluções web elegantes e funcionais.
              Com experiência em React, TypeScript e design responsivo, busco sempre
              entregar projetos de alta qualidade.
            </p>
            <p className="text-gray-600">
              Atualmente focado em desenvolvimento front-end, estou sempre aprendendo
              novas tecnologias e aprimorando minhas habilidades.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
