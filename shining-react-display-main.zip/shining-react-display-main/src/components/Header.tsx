
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <header className="fixed top-0 w-full bg-white/80 backdrop-blur-sm z-50 shadow-sm">
      <nav className="container mx-auto px-6 py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="text-xl font-bold text-gray-800 hover:text-purple-600 transition-colors">
            Portfólio
          </Link>
          <div className="flex gap-6">
            <a href="#about" className="text-gray-600 hover:text-purple-600 transition-colors">Sobre</a>
            <a href="#projects" className="text-gray-600 hover:text-purple-600 transition-colors">Projetos</a>
            <a href="#skills" className="text-gray-600 hover:text-purple-600 transition-colors">Habilidades</a>
            <a href="#contact" className="text-gray-600 hover:text-purple-600 transition-colors">Contato</a>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;
