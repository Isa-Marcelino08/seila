
import { Mail, Github, Linkedin, Twitter } from "lucide-react";

const Contact = () => {
  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12">Entre em Contato</h2>
        <div className="max-w-2xl mx-auto text-center">
          <p className="text-gray-600 mb-8">
            Interessado em trabalhar juntos? Entre em contato através das minhas redes sociais
            ou me envie um email.
          </p>
          <div className="flex justify-center gap-6">
            <a
              href="mailto:seu-email@exemplo.com"
              className="p-3 bg-gray-100 rounded-full hover:bg-purple-100 transition-colors"
              title="Email"
            >
              <Mail className="w-6 h-6 text-gray-700" />
            </a>
            <a
              href="https://github.com/seu-usuario"
              className="p-3 bg-gray-100 rounded-full hover:bg-purple-100 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
              title="GitHub"
            >
              <Github className="w-6 h-6 text-gray-700" />
            </a>
            <a
              href="https://linkedin.com/in/seu-usuario"
              className="p-3 bg-gray-100 rounded-full hover:bg-purple-100 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
              title="LinkedIn"
            >
              <Linkedin className="w-6 h-6 text-gray-700" />
            </a>
            <a
              href="https://twitter.com/seu-usuario"
              className="p-3 bg-gray-100 rounded-full hover:bg-purple-100 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
              title="Twitter"
            >
              <Twitter className="w-6 h-6 text-gray-700" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
